$(document).ready(function () {
    // $("select").addClass('custom-select mr-sm-2')
    // $("input[type=text], input[type=number]").addClass("form-control mb-2 mr-sm-2");
});
